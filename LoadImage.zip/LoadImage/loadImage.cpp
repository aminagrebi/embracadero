//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "loadImage.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
        if(OpenDialog1->Execute()){
   ImageViewer1->Bitmap->LoadFromFile(OpenDialog1->FileName);
   ImageViewer1->BestFit();
 }

}
//---------------------------------------------------------------------------
