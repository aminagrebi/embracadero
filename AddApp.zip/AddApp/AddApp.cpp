//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "AddApp.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
Label1->Text= 7+ Edit1->Text.ToInt();

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
Label1->Text= 8+ Edit2->Text.ToInt();

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
Label1->Text= 9+ Edit3->Text.ToInt();

}
//---------------------------------------------------------------------------
